# Formative Demo

Demo app for the [Formative](https://github.com/jkk/formative) Clojure library.

See it live at [formative-demo.herokuapp.com](http://formative-demo.herokuapp.com/).

## License

Copyright © 2013 Justin Kramer

Distributed under the Eclipse Public License, the same as Clojure.
