<!-- ALL RIGHTS RESERVED - COPYRIGHT 2000-2006 BY TWINFIELD INTERNATIONAL N.V. - WWW.TWINFIELD.COM -->
<html><head><META name="ROBOTS" content="NOINDEX, NOFOLLOW"></head><body onLoad="document.forms[0].txtUserID.focus()"> 
<FORM METHOD="post" ACTION="https://login.twinfield.com/logon">
Gebruikersnaam: <INPUT TYPE="text" NAME="txtUserID"><BR>
Wachtwoord: <INPUT TYPE="password" NAME="txtPassword"><BR>
Administratie : <INPUT TYPE="text" NAME="txtCompanyID"><BR>
<BUTTON TYPE="submit">Inloggen</BUTTON>
</FORM>
<!-- -------------------------------------------------- --> 
<!-- OPMERKING: onderstaande code dient geplaatst te worden in de html op de plaats waar de foutmelding weergegeven dient te worden. 
<!-- -------------------------------------------------- --> 
<?php
$blnError = true;
$strWarning = "";
$strMsg = strtolower((isset($HTTP_GET_VARS['msg']) ? $HTTP_GET_VARS['msg'] : ''));
switch ($strMsg) {
    case "accdisabled":
        $strWarning = "het account is niet actief, neem contact op met de beheerder.";
        break;
    case "incorrect":
        $strWarning = "gebruikersnaam, wachtwoord of administratie is niet juist, probeer opnieuw.";
        break;
    case "loginfirst":
        $strWarning = "voer de account gegevens in, om in te loggen.";
        break;
    case "loggedoff":
        $strWarning = "uitgelogd.";
        $blnError = false;
        break;
    case "companyinactive":
        $strWarning = "de administratie staat uit.";
        break;
    case "wrongbrowser":
        $strWarning = "Het systeem is alleen te gebruiken met Internet Explorer 5.x en hoger";
        break;
    }
    if (strlen($strWarning) >0) {
        if ($blnError) {
            echo 'Fout: ';
        }         
        echo $strWarning;
    }
?>
</body> 
</html>